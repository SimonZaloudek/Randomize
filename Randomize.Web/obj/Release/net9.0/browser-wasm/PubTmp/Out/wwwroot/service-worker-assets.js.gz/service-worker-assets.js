self.assetsManifest = {
  "version": "FagVG9Dn",
  "assets": [
    {
      "hash": "sha256-GIqcs7FZMDEUPDTrLVd3AkZIUfyxNtHP+db7LYyrCnE=",
      "url": "Randomize.Web.styles.css"
    },
    {
      "hash": "sha256-u9iMOIltdEH1f+auTSi7mcb4SBt2memdjfBRiDl2cNE=",
      "url": "_framework/Microsoft.AspNetCore.Authentication.Abstractions.teru10q8m9.wasm"
    },
    {
      "hash": "sha256-RvrgkuvCzUhIR14zDxsUqVpYzujZOdJHMJ36UJgBMIg=",
      "url": "_framework/Microsoft.AspNetCore.Authentication.Core.m4evlbueww.wasm"
    },
    {
      "hash": "sha256-BOlKEtv3+2kMkxKYe+MwTIh7YlgV3xWtXWkbWke6EL0=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.8fivqgib0h.wasm"
    },
    {
      "hash": "sha256-d8NNLZQJd+CbQtkhk8YaiPHZQZb7dW9dVfxbbJXDKIw=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.Policy.tnvtbz267h.wasm"
    },
    {
      "hash": "sha256-h7S85seu8MI7E8vH5QPqVzW64vl96xN/zQBw+PYCHm8=",
      "url": "_framework/Microsoft.AspNetCore.Components.3x6qb1c3az.wasm"
    },
    {
      "hash": "sha256-tN/ojymJTaESrnOP+vjhQGzH7TTnNtyDVcJixfhH6U0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.cur3sl2k62.wasm"
    },
    {
      "hash": "sha256-r9qlVsId0etBHnDLpfdJB19UTt8t80gH4F2UpIZMvE8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.bxoqu3lfsx.wasm"
    },
    {
      "hash": "sha256-EBu0K8SFe/KbDl6H4PhdQZcfOWBAQS9MiNm+0jjq0xo=",
      "url": "_framework/Microsoft.AspNetCore.Hosting.Abstractions.kb9z3q8jmd.wasm"
    },
    {
      "hash": "sha256-KOdV8nnepJvdzz9YZQF2IiESUrXNx6nNMN2Uvhssmi4=",
      "url": "_framework/Microsoft.AspNetCore.Hosting.Server.Abstractions.wyr9zkt2c4.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-sbIJEHnGL6std1HkIJ83mfNTk5yznrGRZbaacPDI5w4=",
      "url": "_framework/Microsoft.AspNetCore.Http.Extensions.57zig84vjd.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-P7u++4zIBAR6s/X8yOsyscat1H9SsWsnAnBNrm4OxlA=",
      "url": "_framework/Microsoft.AspNetCore.Http.f0vd9tuzrq.wasm"
    },
    {
      "hash": "sha256-fg8YBhxVeBw9KgLL74iM1Af2WTkGLgdoV0a8iEXZKWo=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.yjfnd5gwgv.wasm"
    },
    {
      "hash": "sha256-j6JZlsEUb1o4l+vICgRE2dGpULwhBBXXRdQEjOo3C4k=",
      "url": "_framework/Microsoft.AspNetCore.Mvc.Abstractions.rpbpfnzd65.wasm"
    },
    {
      "hash": "sha256-2iSNzaPLe0xEhfVg3AofBuKyE7MglU2cjx7z2V9mH+4=",
      "url": "_framework/Microsoft.AspNetCore.Mvc.Core.ubflkojbnv.wasm"
    },
    {
      "hash": "sha256-m8UHGIYH65v6Dwg+TuJMAhn3s8StKn491tOdYtRSeDo=",
      "url": "_framework/Microsoft.AspNetCore.ResponseCaching.Abstractions.pz2pjv902f.wasm"
    },
    {
      "hash": "sha256-P40QIMDnLSgSyIDX+T6b/vJp3BAHSY9fCgOHP7xz0tA=",
      "url": "_framework/Microsoft.AspNetCore.Routing.Abstractions.vw6dpka42w.wasm"
    },
    {
      "hash": "sha256-jJmi/NxlyHHBUsjNbdV6wFuewaDCNut1c0H8z289WWI=",
      "url": "_framework/Microsoft.AspNetCore.Routing.oblefhb002.wasm"
    },
    {
      "hash": "sha256-VQM0rTyQ42zNsi2Mfz/XlOZsi4F4HQ5RrZnGIJaRhjI=",
      "url": "_framework/Microsoft.AspNetCore.WebUtilities.3iepfijnwt.wasm"
    },
    {
      "hash": "sha256-AyqxqVU4FL3BWIKZL8y58oW5FfOZHR29D2Tm4WNFxho=",
      "url": "_framework/Microsoft.CSharp.9hdb1rphr2.wasm"
    },
    {
      "hash": "sha256-VxnZGlNfs8zsMPJbhOGV8YeKlbz32rG2wThdBbGqmM0=",
      "url": "_framework/Microsoft.DotNet.PlatformAbstractions.pgti5bhltf.wasm"
    },
    {
      "hash": "sha256-nhak/Ch7TOrbT2umyoexChLkVbr45zSylnziTDlG7Tk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.ikcfkawg8q.wasm"
    },
    {
      "hash": "sha256-TxOo9nPmVL3U9K4TaX1871k0es8meg5RhQtvn2xXGbc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.x8nc4ezhyo.wasm"
    },
    {
      "hash": "sha256-FbbkCztqkDMz5rh3sGQ3/d/xGFh4KloSaMpO8OHC9gw=",
      "url": "_framework/Microsoft.Extensions.Configuration.pz14rylzl4.wasm"
    },
    {
      "hash": "sha256-vgVm6YkgnNMB8rR8J1FtDpTiCYyo1l3qvK2hCTAuVkM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.2bj47peqww.wasm"
    },
    {
      "hash": "sha256-bPy3LxeuvYfO4/jhJ/LrMmHMsx/e50ZX3UX6x2QDxZU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.g5xbvywp58.wasm"
    },
    {
      "hash": "sha256-OcslAdsfDq7oiLiVV/CrUyd+oj/k2rMIUj5FMbfKY/M=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.z5fchb6t5z.wasm"
    },
    {
      "hash": "sha256-0/vlRngZjZDCWw1TXTcE7oRpX/BkuS81WGDrPcdfE1U=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.hb1ixjwlk9.wasm"
    },
    {
      "hash": "sha256-GZUfNSb7s4DhZTIyR/VONc/Je1brtrZ+gISX8A1obkU=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.b7eodwav1j.wasm"
    },
    {
      "hash": "sha256-zzyT2Y3Mj81XE18OyBSIv8FO1idj0hAE/TJjVFgjqO4=",
      "url": "_framework/Microsoft.Extensions.Logging.jzd06wzi58.wasm"
    },
    {
      "hash": "sha256-zgIuDNpTj8i+xv3knwRZrhPvKq+uBhTjAbCMJtMs6dk=",
      "url": "_framework/Microsoft.Extensions.ObjectPool.20349j4g2z.wasm"
    },
    {
      "hash": "sha256-B1ciuISTYqpeDGW+h2oXZ1e/4geUIQ2fuR/RNGXatXk=",
      "url": "_framework/Microsoft.Extensions.Options.zttou3yn8o.wasm"
    },
    {
      "hash": "sha256-lGXIWbg30bcJ4YC5ipMBKbX7vRtMFd3U9lXt6OHEHPs=",
      "url": "_framework/Microsoft.Extensions.Primitives.8b00kof22a.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-WlaGysW+2KH8VX+Fw/WhpDv9XQwLvF+eOm/AnPSKn4I=",
      "url": "_framework/Microsoft.JSInterop.um7ki97jms.wasm"
    },
    {
      "hash": "sha256-jfXK+cfJd/PteHB+5Bay/NDY9b9VLvVw6G/Bm262Lpo=",
      "url": "_framework/Microsoft.Net.Http.Headers.vhfw8f9f40.wasm"
    },
    {
      "hash": "sha256-DBfpbduzEP2lTeFZddrFGuNDOcOwgBPZwFsTYJEFsSA=",
      "url": "_framework/Newtonsoft.Json.se2bgyj0tw.wasm"
    },
    {
      "hash": "sha256-APMSfdlFVDWBygWKTQqmF/uapZ1L2jW8EoiF+MxmOY4=",
      "url": "_framework/Randomize.Core.8e8mlh2c5g.wasm"
    },
    {
      "hash": "sha256-dyZMhcE+BMbQSdtc0gwgyHkWTt+rcCRXa5j3Wx+JUVU=",
      "url": "_framework/Randomize.Web.hijbmffd13.wasm"
    },
    {
      "hash": "sha256-IjmnNlelpEtZI96gN5XWWl6TJxlDgR7L3bNbofzOdwA=",
      "url": "_framework/ServiceStack.Common.y47ozvehyh.wasm"
    },
    {
      "hash": "sha256-XQqsFFyzO0yDYMqUiXOR9XAJfNINPRhLT+pve0naFso=",
      "url": "_framework/ServiceStack.Interfaces.r28bwqbei9.wasm"
    },
    {
      "hash": "sha256-/uaO6j+Hks3pXxcEVJAnI1zmjIpj2qadyNNXhVwWGso=",
      "url": "_framework/ServiceStack.Text.63lpmndeff.wasm"
    },
    {
      "hash": "sha256-Xttwe2OIhph5xmBAa6xpiCSTBA8fzON7Lygo3VZ2tXw=",
      "url": "_framework/System.AppContext.qt3k3mdvi7.wasm"
    },
    {
      "hash": "sha256-tthJNNU0mplKP4IUrAfO06LS07+0cBmqF4rx3Qi3AEg=",
      "url": "_framework/System.Buffers.eawxfy4p74.wasm"
    },
    {
      "hash": "sha256-htjP/bTT5sS19n8qz8ZomN37XzDd7McF+5aw6vzFvXY=",
      "url": "_framework/System.Collections.Concurrent.efd6muxmuk.wasm"
    },
    {
      "hash": "sha256-VDYZgrzAyE7rVWIgC5c0ZatGNEr4ujdQszIJ2EqXxes=",
      "url": "_framework/System.Collections.Immutable.c065gf7clg.wasm"
    },
    {
      "hash": "sha256-qEH5hk7RdTqlYhO3jK4Zm4R06HoUgS3D4D6Jdk5FZWY=",
      "url": "_framework/System.Collections.NonGeneric.osxxdqoxla.wasm"
    },
    {
      "hash": "sha256-MOMcF5ZDDHea1f/y85Eie4KyvoH6F7TE+uMUhoomIw4=",
      "url": "_framework/System.Collections.Specialized.goeq0g5fhh.wasm"
    },
    {
      "hash": "sha256-hC+SsNQBer6DsQKbGoC5pfaydqExH5LkkfaC/sytD/M=",
      "url": "_framework/System.Collections.wnu5ydr9xo.wasm"
    },
    {
      "hash": "sha256-3KUHbMeQ9rnsXpeQ9foY8OTcukNCFM438/5ebjoyThA=",
      "url": "_framework/System.ComponentModel.Primitives.c25m74iu8q.wasm"
    },
    {
      "hash": "sha256-eI0SkEHdWrQKv4HzIB32vkdmd04jgKj4U8NLhDHIndo=",
      "url": "_framework/System.ComponentModel.TypeConverter.wmgd8w3ljf.wasm"
    },
    {
      "hash": "sha256-+t8P5VwB9QreGtaNHR5OsuxiRQ8ToVQvFiE4CXb2sQE=",
      "url": "_framework/System.ComponentModel.avqctkouua.wasm"
    },
    {
      "hash": "sha256-1A+iVv3xq+UFNFJFSJAN/Qk8XOKNb/RT58nd6nzR7Ms=",
      "url": "_framework/System.Console.cai1pxi80g.wasm"
    },
    {
      "hash": "sha256-QZ4xnSv8dHvttImtOlyZdOkLdlSsnj6sJYHUVCw47tc=",
      "url": "_framework/System.Data.Common.j7bcu8acu8.wasm"
    },
    {
      "hash": "sha256-UDaF22RtsZeK9FrgSkd63EtcG/8+1X6cMEM0FyFY+JM=",
      "url": "_framework/System.Diagnostics.Debug.sh3s5t1oxb.wasm"
    },
    {
      "hash": "sha256-CN7m9cacA3laWBBfcDAEqJDhFNKESsKQglPKqSW0f28=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.sz4ntefl13.wasm"
    },
    {
      "hash": "sha256-xCZuOPMgMGC0m3a8cf4PPUD7WpYEA4SSjjT0JBd8MuQ=",
      "url": "_framework/System.Diagnostics.Process.grumwxxt0w.wasm"
    },
    {
      "hash": "sha256-b9MJ8LwuDgsdnIilgGhHuZ1S6kCsTVgHDl9U+bO5Jos=",
      "url": "_framework/System.Diagnostics.Tracing.j3j3w0v1q6.wasm"
    },
    {
      "hash": "sha256-qrMJlO3J8h/mZyox8k6bhziksIaKMowHe58ceXyrM8M=",
      "url": "_framework/System.Dynamic.Runtime.i5t3ui3s3h.wasm"
    },
    {
      "hash": "sha256-hdi20ZMyLNmledb7Cge1uiEbflC/P0EqiB0Mx1pVeEU=",
      "url": "_framework/System.Globalization.fnn35yezva.wasm"
    },
    {
      "hash": "sha256-iTYKOnQw8SE+OpAcGbk0OXDuFpCG948t1D7UWoeoFWk=",
      "url": "_framework/System.IO.FileSystem.9kvzc0isz3.wasm"
    },
    {
      "hash": "sha256-eCk4H2NQy5QA48ApNF/rtOM0tX/XtGFkM0ohrV6SCiU=",
      "url": "_framework/System.IO.FileSystem.Primitives.s3fwpv8sni.wasm"
    },
    {
      "hash": "sha256-DOS3631fUKSvbgYYQ0EtoOsoqV7wDE8Xh4FViJerdx8=",
      "url": "_framework/System.IO.Pipelines.ozf0bs3f96.wasm"
    },
    {
      "hash": "sha256-D/aHZN+xhq9Pxh+PakP0T6wpkNnWJYIuQdCHCnI+1Fc=",
      "url": "_framework/System.IO.r9n5lr3dg5.wasm"
    },
    {
      "hash": "sha256-91FvOPsJF+hAURAx2P3vQvFc6jvDYKV9RSsjUxUhKN0=",
      "url": "_framework/System.Linq.Expressions.rvkhqhtri3.wasm"
    },
    {
      "hash": "sha256-Fq6rfEfStiNoxhH+0BDLOCqhlmUPsJYfHMv9xoaE+1I=",
      "url": "_framework/System.Linq.Queryable.av753lyyfe.wasm"
    },
    {
      "hash": "sha256-oMU/Q1KfywDhynIXIwyT5i8qd8RTNXuJzd9oM2tcADM=",
      "url": "_framework/System.Linq.o6fuae1lje.wasm"
    },
    {
      "hash": "sha256-fzOsO4XTWmYmgCYQYWZ2SHeS7nCCzKSaBiAhBHUrXe0=",
      "url": "_framework/System.Memory.bpb9cl5dm2.wasm"
    },
    {
      "hash": "sha256-SuXEunOX8FGjBKZXGhDX0QJkwiNecfgtiNLxz5OHbbk=",
      "url": "_framework/System.Net.Http.ih05humppb.wasm"
    },
    {
      "hash": "sha256-WtWO9Jja2E5dWh6/Gmc/YmwyazVTBUAbrksNKI9gvYc=",
      "url": "_framework/System.Net.NetworkInformation.ub7lxrnha7.wasm"
    },
    {
      "hash": "sha256-Eur28oyYM42ptqzXdna3wRI2F2vFtgqfGj7J/0wuw8A=",
      "url": "_framework/System.Net.Primitives.62yu23qdv0.wasm"
    },
    {
      "hash": "sha256-OaK2eJpJs1g9Bwxv0GnwWWqfdSfSmDefE69eYDeYD3Y=",
      "url": "_framework/System.Net.Requests.hml75dc8cx.wasm"
    },
    {
      "hash": "sha256-6jb3qBtkv+gNK5kl6LHelZCEsbZCxEfqZcqyAcW9F90=",
      "url": "_framework/System.Net.Sockets.im0no7sin6.wasm"
    },
    {
      "hash": "sha256-h6gUimiqxsFmijvneoLyyS946g8MwLxigMpNtwhBcag=",
      "url": "_framework/System.Net.WebHeaderCollection.j150jn6ujs.wasm"
    },
    {
      "hash": "sha256-jwuLxu+kdYyKIfbgNOBBNzAUAAgPuRzLTkvVWHYcH+k=",
      "url": "_framework/System.Net.WebSockets.hkl9rpqm7q.wasm"
    },
    {
      "hash": "sha256-PXMKQIxvpExJ4CTqbVSStdIilZcPWmK/gCxgMnxqRt4=",
      "url": "_framework/System.ObjectModel.1fexgnybfy.wasm"
    },
    {
      "hash": "sha256-5qK3laeL4z7f8M7at9VFNBOJgkMAIi+eHEpwaXmjEfY=",
      "url": "_framework/System.Private.CoreLib.a8z38s51te.wasm"
    },
    {
      "hash": "sha256-jDNqKNzdycMwF5iHCC2w//mgcfXju0x7asuCKFW+6QI=",
      "url": "_framework/System.Private.DataContractSerialization.scku1017we.wasm"
    },
    {
      "hash": "sha256-H5t49Wx+iBQvEgtQmPv+mMN6Ao0VGsJrhsAvhilSO64=",
      "url": "_framework/System.Private.Uri.v4fmpbapsz.wasm"
    },
    {
      "hash": "sha256-vmnsgP7iRBu5Pm1E28xePg0X4E9Qdpiqj6S1BadrquE=",
      "url": "_framework/System.Private.Xml.Linq.mfthngz8e8.wasm"
    },
    {
      "hash": "sha256-wfitKZ+SSD4NHqYvzChTAFSpXMdDyAQquQTC9ErU62U=",
      "url": "_framework/System.Private.Xml.xszyz7dzzk.wasm"
    },
    {
      "hash": "sha256-CutuW+sXML6Ur9l3IdzsSrPGDEBrjb23r3nyS8Dq/S8=",
      "url": "_framework/System.Reflection.607euz7har.wasm"
    },
    {
      "hash": "sha256-57e7L2HMGahZoYKZUDHBy21O8X1rgV5lw7sBaPjwmnA=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.j5mv64ekdp.wasm"
    },
    {
      "hash": "sha256-W02kwFeT7gah5eOVWunv8EoyIv0og7oxpb1BKE7GvKM=",
      "url": "_framework/System.Reflection.Emit.Lightweight.54xoxtebge.wasm"
    },
    {
      "hash": "sha256-silAOLORBGNZnn2mW7eGNBbF74fSlFmO/SqprXihoCc=",
      "url": "_framework/System.Reflection.Emit.i8klc9wqh6.wasm"
    },
    {
      "hash": "sha256-XIMfDNhNGp1F34LAcB1bDHwAiaf/oHR/AcDncc6VKEc=",
      "url": "_framework/System.Reflection.Extensions.sclt6fpam5.wasm"
    },
    {
      "hash": "sha256-dapLgk9nThxrxcEz9ngzfRJWCKwwghKj/jHka+kVPDQ=",
      "url": "_framework/System.Reflection.Primitives.h57hc4htkk.wasm"
    },
    {
      "hash": "sha256-eaRYKIZ7sssS2kyQM96DwvaFUX7Vf9Yfv+bHxBaTaMo=",
      "url": "_framework/System.Resources.ResourceManager.dbeknebgal.wasm"
    },
    {
      "hash": "sha256-JXlx9r95W3uGiZ4h+5gZFDGuC3zgmp4Vzzzs4bHQQgU=",
      "url": "_framework/System.Runtime.Extensions.rs9lyshkhc.wasm"
    },
    {
      "hash": "sha256-p1LD0fpgFsTckIcsUH+xkP6qPuHbu2ht7Qc9DhOztmY=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.pkvqfb5bgf.wasm"
    },
    {
      "hash": "sha256-MBa7JrZaaGLtkIZef2FIGCsi0t82KGp8VQE+T/5yMPU=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.0gt3i41pjx.wasm"
    },
    {
      "hash": "sha256-n+I5SI1hgE5jay/bjEEtWAJU8ex4vm0PRUkQA3pdY6o=",
      "url": "_framework/System.Runtime.InteropServices.vwk71jvb9q.wasm"
    },
    {
      "hash": "sha256-7ChcQuMHWpgVGknFtPEgaQD5WDiMrg8fAdscvdWqZJk=",
      "url": "_framework/System.Runtime.Serialization.Formatters.s87tnmhrbt.wasm"
    },
    {
      "hash": "sha256-gY226LysNAlL/ihrt5vHZyIzCGi0xL5BUDOAugQZ0yM=",
      "url": "_framework/System.Runtime.Serialization.Primitives.pac9b7kdpn.wasm"
    },
    {
      "hash": "sha256-7Lj86XX7R36oOPF/2nLUitX094qIg7KMn+0jXqoTzAs=",
      "url": "_framework/System.Runtime.Serialization.Xml.4kojk8dn0h.wasm"
    },
    {
      "hash": "sha256-mOSGyg0QV/gh3e0gsppdkwoW7h6tNT4Zcmi0HY35qz4=",
      "url": "_framework/System.Runtime.ow4ngb1d7a.wasm"
    },
    {
      "hash": "sha256-dkMQyonNv1AkN7r3wtZqW6XQeJKQNQDVBJMDU8BQtTw=",
      "url": "_framework/System.Security.Claims.q72d7ofx8h.wasm"
    },
    {
      "hash": "sha256-eXc/R8SfuCr4E6gusmf0QpZM/Q4cnfN3gr5ERQZCSDE=",
      "url": "_framework/System.Security.Cryptography.jtajz6vg75.wasm"
    },
    {
      "hash": "sha256-c8WlVapzIkhfn5ebVK9PSfrXz7N0OVPQqdn+GPTWGVg=",
      "url": "_framework/System.Text.Encoding.7jsgpu2rro.wasm"
    },
    {
      "hash": "sha256-Ji/C6LNmwYPyOfBsKk1zNoHaxEtTYQjR6mP09n5aWqc=",
      "url": "_framework/System.Text.Encoding.Extensions.en5d30xiuq.wasm"
    },
    {
      "hash": "sha256-bKcOUm6D1TH/rXC0o4FQuGOeXq7DkFBiYSbHT+SagZg=",
      "url": "_framework/System.Text.Encodings.Web.c205pwhud8.wasm"
    },
    {
      "hash": "sha256-ULnMY/u3S4mnashqKoFiD7Y5DMB3hLiKN8xk1ei2kmM=",
      "url": "_framework/System.Text.Json.cp632cpq3s.wasm"
    },
    {
      "hash": "sha256-Crn/+lZ1ZfitTT6CLb4OLWjUKVF0s0GShAS+mRHTdwo=",
      "url": "_framework/System.Text.RegularExpressions.mwu2algq7t.wasm"
    },
    {
      "hash": "sha256-LLLbb8qA17ufGkHZymABuu+sERfr05v5BzfPUotr5As=",
      "url": "_framework/System.Threading.Tasks.401fvzbsip.wasm"
    },
    {
      "hash": "sha256-jDoBkjoB6dmLETQaju5DTpoYl+W2V8/Nmypa8+gwVEo=",
      "url": "_framework/System.Threading.Tasks.Extensions.g1w9zyblcw.wasm"
    },
    {
      "hash": "sha256-WnAzkxJfKfrasSFtu4xGTjOaYFg/ErF4BAftG1ABieY=",
      "url": "_framework/System.Threading.Thread.2d1rg0ozfh.wasm"
    },
    {
      "hash": "sha256-Wyxg9sImynTFv6YGUdme0hMwV4PVV1EBvmbDiU6sATU=",
      "url": "_framework/System.Threading.dqf828v2i8.wasm"
    },
    {
      "hash": "sha256-mbYGP0LGPc5vvAcBsJSyW5l3bCBmvuZcPtJM/pCswrA=",
      "url": "_framework/System.Xml.Linq.5pth2pwj0z.wasm"
    },
    {
      "hash": "sha256-/8155wAJKvWMwB0CvrB6GfbMq/LLBmNhH7WPhSimvhQ=",
      "url": "_framework/System.Xml.ReaderWriter.dhhy19ghdd.wasm"
    },
    {
      "hash": "sha256-RoDPqGJIyp8Zs4bUBn6ZJZUVTL9sMGCBvDQ/dV//PC8=",
      "url": "_framework/System.Xml.XDocument.m8p67dkr3z.wasm"
    },
    {
      "hash": "sha256-tVaTeiubnxofQV5rO7ga2UOORIQEtLkQr36ewcMO+tw=",
      "url": "_framework/System.t250xnkyfs.wasm"
    },
    {
      "hash": "sha256-ExY9umanttg9GMV8dGwm30xW5iqz9y8Uf/RKZkAwXj8=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-FNnlNxsI/YRu1XzSvpFf5ooMdu3Lm78Tybc7kaUXt8I=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-i7Ti7oQs36plu2O2qirzK1+9ilcJLmWqAtlDbuZGeZw=",
      "url": "_framework/dotnet.native.vz0adxojrz.wasm"
    },
    {
      "hash": "sha256-wcPTC3mDpEcT24XjJe50tp5nZPwae2BBvtQVsRs4FN4=",
      "url": "_framework/dotnet.native.xsn1d6x2kd.js"
    },
    {
      "hash": "sha256-zZ0MGlWZF0pG99PvNYvOdUvox/BZe6pddrswXlZoKyc=",
      "url": "_framework/dotnet.runtime.dstopyvqzi.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-AYrk0lUFy9aYaGYKj+3zPitWwL+UCc52+0R7T5yuubE=",
      "url": "_framework/netstandard.voo4c99pl9.wasm"
    },
    {
      "hash": "sha256-+/KPrZwIYpDVEOuemFomFBoY1yz9rStith99lPlUKC4=",
      "url": "brand/RANDLOGO1.png"
    },
    {
      "hash": "sha256-zcxj09lMGs1VRwJip8vYuj6HbN8g+uABG8gawBfsJUQ=",
      "url": "brand/RANDLOGO2.png"
    },
    {
      "hash": "sha256-c/BLkU840a1nFqXGpSNTOfhNG7dTgeGTw9TTCiUHi2k=",
      "url": "brand/randlogofull.png"
    },
    {
      "hash": "sha256-zCbfEdACqf9juC1T0lcQXCXb/M8eI9pIBLgfCBs9U6c=",
      "url": "brand/randlogofull2.png"
    },
    {
      "hash": "sha256-9m3xdM1C56/kMRgi9Bkn6P3tMjvnZjXRJ4U2VTyPQOQ=",
      "url": "brand/randlogofull3.png"
    },
    {
      "hash": "sha256-dFyHryE6RSXwAnLjiC0C2fXNr1xIF0q071/sJ+41Fkw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-KpNC5QOGDLf8se7wgCmJ4mZgeIW+62s0z6xGQknekhg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-tB6JTjuHKRolOi4ah9x/CVyGTY9SCIn36NNbKUEC4nA=",
      "url": "js/save.js"
    },
    {
      "hash": "sha256-Yk4WEBetgJR/X6tQEK/Qgr6nVIOC+13Op9xw/Txw6PI=",
      "url": "js/wheel.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-dj0h93N8Hk+qV2KXnr+PxGd2bHY4SjFlPOCfiOG0VvU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-ywrP01RjIBQ3n59xYlvGUT4msYrOLUCZ1q+IEBM2mLY=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-vJQ+1mVJXqCsykX3FqGd8fMwKLHvXa46EFcGxI5nq3M=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-WIVsay8TYGZEeRegZm9CZADMeppwI7NzFB+ReYtmTvI=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-RkiT36TaUFHzZzUB86ksndFdgTUvV1EmeMGYR596PFk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-rviKzY17hhcFpsrlYDDaEzEjKaX4aPRe40i0WCnEcoU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Jot5kUnIvOeyfgdDKk2+Yz8+HCnKPWVzGQHwitLSN/g=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-w8bmqxPOkTkMTHHLSiPDPXzXpF6+x/QKhNZQWCzOQPU=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-9jdTHNBXddc5L/t0VfNh8lq01ud3Ub+1ZhSjqhVvvqA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-mCPK5o+uF23r60linECb69boWIDITyainaNaSuVwgLw=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
